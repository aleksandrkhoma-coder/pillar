// Pillar Dashboard — Worker (per-PM access)
// Власник (Олександр): приватне посилання БЕЗ пароля -> увесь портфель.
//   Один раз відкрий:  https://ТВІЙ-ДОМЕН/?key=OWNER_KEY
//   Воркер запамʼятає тебе через cookie на рік — далі заходь просто на корінь.
// ПМи: вхід за логіном/паролем, кожен потрапляє на свою сторінку.

const OWNER_KEY = '1f19b18b059ac0beeb50f14f4e1fb16c4b3d697f0d06ad74';

const USERS = {
  donskaya:       { pass: 'Donska#2026',      page: '/pillar_pm_donskaya.html' },
  aleksandrov:    { pass: 'Aleks#2026',        page: '/pillar_pm_aleksandrov.html' },
  ishchuk:        { pass: 'Ishchuk#2026',      page: '/pillar_pm_ishchuk.html' },
  zayanchkovskyi: { pass: 'Zayan#2026',        page: '/pillar_pm_zayanchkovskyi.html' },
  khoma:          { pass: 'Khoma#2026',        page: '/pillar_pm_khoma.html' },     // син — лише його проєкт
  admin:          { pass: 'PillarAdmin#2026',  page: '/pillar_portfolio.html' },    // резервний повний доступ
};

const REALM = 'Pillar Portfolio Dashboard';
const COOKIE = `pillar_owner=${OWNER_KEY}; Path=/; Max-Age=31536000; Secure; HttpOnly; SameSite=Lax`;

function getUser(request) {
  const auth = request.headers.get('Authorization');
  if (!auth || !auth.startsWith('Basic ')) return null;
  try {
    const decoded = atob(auth.slice(6));
    const colon = decoded.indexOf(':');
    if (colon < 0) return null;
    const user = decoded.slice(0, colon).toLowerCase().trim();
    const pass = decoded.slice(colon + 1);
    if (USERS[user] && USERS[user].pass === pass) return user;
    return null;
  } catch {
    return null;
  }
}

function hasOwnerCookie(request) {
  const c = request.headers.get('Cookie') || '';
  return c.split(/;\s*/).some(p => p === `pillar_owner=${OWNER_KEY}`);
}

function unauthorizedResponse() {
  return new Response(
    `<!DOCTYPE html>
<html lang="uk"><head><meta charset="UTF-8"><title>Pillar — Вхід</